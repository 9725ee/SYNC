sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    'sap/ui/model/Filter', 
    'sap/ui/model/FilterOperator'
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller,JSONModel,Filter,FilterOperator) {
        "use strict";

        return Controller.extend("exam.exprogram01.controller.Main", {
            onInit: function () {
                this.oRouter = this.getOwnerComponent().getRouter();
                var oRouter = this.getOwnerComponent().getRouter();

                var oData = {
                    CategoryID : " ",
                    ProductName : " ",
                    UnitsInStock : " ",
                    UnitsOnOrder : " "
                }
                this.getView().setModel(new JSONModel(oData),"categoery");

            },
            onGoDetail : function(){
                this.oRouter.navTo('RouteDetail', {}, true);
            },

            onSearch:function(){
                var oTable = this.byId("tableID");
                var oBinding = oTable.getBinding("items");

                var sId = this.byId("InputId").getValue();
                var sCn = this.byId("InputId2").getValue();

                var aFilter = [] ;

                if(sId){
                    var aFilter = new Filter({
                        path : 'CategoryID',
                        operator : 'GE',
                        value1 : sId
                    });
                }

                if(sCn){
                    var aFilter = new Filter({
                        path : 'CategoryName',
                        operator : "Contains",
                        value1 : sCn
                    });
                }
                    oBinding.filter(aFilter);

                if (aFilter.length === "0") {
                    oBinding.filter([]);
                } 
            },

            onSelectionChange : function(oEvent){

                //문제3번 
                var oTable = oEvent.getSource();
                var oSelectedCategory = oTable.getSelectedItem().getBindingContext().getObject();
                var sCategoryID = oSelectedCategory.CategoryID;

                var oModel = this.getView().getModel();
                var oProductTable = this.byId("productId");
                
                oProductTable.getBinding("rows").filter(new Filter("CategoryID", "EQ", sCategoryID));
   

                //문제4번
                var select = this.byId("tableID").getModel("categoery");

                var aFilter = [];
                
                if(select){
                    this.byId("idVizFrame").setData(select);}

               
            }
        });
    });
