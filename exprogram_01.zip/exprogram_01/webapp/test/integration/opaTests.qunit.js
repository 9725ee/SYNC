/* global QUnit */

sap.ui.require(["exam/exprogram01/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
